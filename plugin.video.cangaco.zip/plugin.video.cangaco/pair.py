import time
import xbmc
import os
import xbmcgui
import urllib2
import webbrowser
if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
def pairkratos ( ) :
 oo = xbmcgui . Dialog ()
 i1iII1IiiIiI1 = (
 iIiiiI1IiI1I1 ,
 o0OoOoOO00 ,
 I11i ,
 O0O
 )
 if 78 - 78: i11ii11iIi11i . oOoO0oo0OOOo + IiiI / Iii1ii1II11i
 iI111iI = oo . select ( '[B][COLOR=green]Kratos Kodi BR[/COLOR][COLOR yellow] Pareamento[/COLOR][COLOR=lime] PAIRNG TOOL[/COLOR][/B]' , [
 '[B][COLOR=skyblue]      OpenLoad[/COLOR][/B]' ,
 '[B][COLOR=skyblue]      The Video Me[/COLOR][/B]' ,
 '[B][COLOR=skyblue]      Vid Up Me[/COLOR][/B]' ,
 '[B][COLOR=skyblue]      vShare.eu[/COLOR][/B]' ] )
 # dialog.selectreturns
 #   0 -> escape pressed
 #   1 -> first item
 #   2 -> second item
 if iI111iI :
  if 34 - 34: iii1I1I / O00oOoOoO0o0O . O0oo0OO0 + Oo0ooO0oo0oO . I1i1iI1i - II
  if iI111iI < 0 :
   return
  Oo = i1iII1IiiIiI1 [ iI111iI - 4 ]
  return Oo ( )
 else :
  Oo = i1iII1IiiIiI1 [ iI111iI ]
  return Oo ( )
 return
 if 27 - 27: o00 * O0IiiiIiI1iIiI1 - ii1Ii * ooO0Oooo00 % oo00 * Iii1ii1II11i
def o0000o0o0000o ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) :
  return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) :
  return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) :
  return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) :
  return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) :
  return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) :
  return 'ios'
  if 79 - 79: ii1Ii
oOo0oooo00o = o0000o0o0000o ( )
if 65 - 65: O00oOoOoO0o0O * iIii1I11I1II1 * oo00
def iIiiiI1IiI1I1 ( ) :
 if oOo0oooo00o == 'android' :
  IiI1i = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
 else :
  IiI1i = webbrowser . open ( 'https://olpair.com/' )
  if 61 - 61: O0oo0OO0 + II / ooO0Oooo00 . O00oOoOoO0o0O
def o0OoOoOO00 ( ) :
 if oOo0oooo00o == 'android' :
  IiI1i = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://tvad.me/pair' ) )
 else :
  IiI1i = webbrowser . open ( 'https://tvad.me/pair' )
  if 72 - 72: IiiI % I1i1iI1i . oOoO0oo0OOOo / II * oOoO0oo0OOOo
def I11i ( ) :
 if oOo0oooo00o == 'android' :
  IiI1i = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://thevideo.me/pair' ) )
 else :
  IiI1i = webbrowser . open ( 'https://thevideo.me/pair' )
  if 31 - 31: i11ii11iIi11i + Iii1ii1II11i . ooO0Oooo00
def O0O ( ) :
 if oOo0oooo00o == 'android' :
  IiI1i = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://vshare.eu/pair' ) )
 else :
  IiI1i = webbrowser . open ( 'http://vshare.eu/pair' )
#  if 68 - 68: oOoO0oo0OOOo - i11iIiiIii - Iii1ii1II11i / I1i1iI1i - Iii1ii1II11i + i1IIi
#o0OO00( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3

